from flask.helpers import url_for
from werkzeug.utils import redirect
from appPackage import appInstance
from flask import render_template, flash
from appPackage.forms import LoginForm

@appInstance.route('/')
@appInstance.route('/index')
def index():
    user = {'username': 'Joseph'}
    posts = [
        {
            'author': {'username': 'John'},
            'body': 'Beautiful day in Portland!'
        },
        {
            'author': {'username': 'Susan'},
            'body': 'The Avengers movie was so cool!'
        }
    ]
    return render_template("index.html", title="Home", user=user, posts=posts)

@appInstance.route('/login', methods=["GET","POST"])
def login():
    form = LoginForm()
    # ensures required fields have been entered
    if form.validate_on_submit():
        #without data would not just give value but info such as type
        flash("Login requested for {}, remember me = {}"
        .format(form.username.data, form.remember_me.data))
        return redirect(url_for("index"))
    return render_template("login.html", title="Sign In", form=form)
