from flask import Flask
from config import Config

appInstance = Flask(__name__)
# config (subclass instance of dictionary) is an attribute of Flask class, 
# from_object updates config attribute to Config class
appInstance.config.from_object(Config)

#placing at bottom avoids "circular imports" because routes imports appInstance...?
#(EXPLAINED: importing routes wouldn't work if you don't have an app instance)
from appPackage import routes